"use strict";
module.exports = {
    auth: require("./auth"),
    users: require("./users"),
    books: require("./books"),
    issue: require("./issue")
};
