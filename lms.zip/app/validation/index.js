module.exports = {
    login: require("./login"),
    register: require("./register"),
};
