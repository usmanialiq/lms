module.exports = {
    error: require("./errors"),
    success: require("./success"),
};
