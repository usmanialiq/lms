"use strict";
module.exports = {
    // mongoURI: 'mongodb://admin:super1@ds217976.mlab.com:17976/tm_mern',
    secretOrKey: "bloodyBitch",
    cloudinary: {
        cloud: "dvmqrtgg8",
        apiKey: "483224312734381",
        apiSecret: "VHcwC5MKCA6lrZFNnJXSLMu1Y10",
    },
    sendGrid: {
        apiKey: "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"
    },
};
