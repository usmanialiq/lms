let host = "http://localhost:3001/api";

export const login = host + "/login";
export const register = host + "/register";
export const books = host + "/books";
export const checkout = host + "/checkout";
export const users = host + "/users";